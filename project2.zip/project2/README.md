# Full-stack-Nanodegree
## Project 2: Build a Portfolio Site
**Project Description** (from Udacity):
>For this project, you'll be building a portfolio website. You will be provided a design mockup as a PDF-file, and you must replicate that design in HTML and CSS. You will develop a responsive website that will display images, descriptions and links to each of the portfolio projects you will complete through the course of your Nanodegree program. Please note that while you should aim to recreate the mockup, you may also use your own custom images to personalize this project.

### Usage
Download index.html and the img and css folders (with all content inside). <br>
Open your Downloads folder <br>
Double click on index.html to view in web browser